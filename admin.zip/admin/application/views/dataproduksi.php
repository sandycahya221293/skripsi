<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-plane"></i> Data Produksi Management
        <small>Add, Edit, Delete</small>
      </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12 text-right">
                <div class="form-group">
                    <a class="btn btn-primary" href="<?php echo base_url(); ?>addDataProduksi"><i class="fa fa-plus"></i> Baru </a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                    <h4 class="box-title">Data Produksi List</h4>
                    <div class="box-tools">
                        <form action="<?php echo base_url() ?>produksiListing" method="POST" id="searchList">
                            <div class="input-group">
                              <input type="text" name="searchText" value="<?php echo $searchText; ?>" class="form-control input-sm pull-right" style="width: 150px;" placeholder="Cari"/>
                              <div class="input-group-btn">
                                <button class="btn btn-sm btn-default searchList"><i class="fa fa-search"></i></button>
                              </div>
                            </div>
                        </form>
                    </div>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                  <table class="table table-hover" >
                    <tr>
                      <th>No Produksi</th>
                      <th>Tanggal Terima</th>
                      <th>Costumer</th>
                      <th>Kode Gambar</th>
                      <th>No Desain</th>
                      <th>No Strikeoff</th>
                      <th>Konstruksi</th>
                      <th>Combo</th>
                      <th>Tanggal Selesai</th>
                      <th>Desain</th>
                      <th>Keterangan</th>
                      <th class="text-center">Actions</th>
                    </tr>
                    <?php
                    if(!empty($dataRecords))
                    {
                        foreach($dataRecords as $record)
                        {
                    ?>
                    <tr>
                      <td><?php echo $record->no ?></td>
                      <td><?php echo $record->tglterima ?></td>
                      <td><?php echo $record->costumer ?></td>
                      <td><?php echo $record->kodegambar ?></td>
                      <td><?php echo $record->nodesain ?></td>
                      <td><?php echo $record->noso ?></td>
                      <td><?php echo $record->konstruksi ?></td>
                      <td><?php echo $record->combo ?></td>
                      <td><?php echo $record->tglselesai ?></td>
                      <td><?php echo $record->desainer ?></td>
                      <td><?php echo $record->keterangan ?></td>
                      <td class="text-center">
                          <a class="btn btn-sm btn-info" href="<?php echo base_url().'editdataproduksi/'.$record->no; ?>"><i class="fa fa-pencil"></i></a>
                          <a class="btn btn-sm btn-danger deleteUser" href="<?php echo base_url().'user/deleteProduksi/'.$record->no; ?>"><i class="fa fa-trash"></i></a>
                      </td>
                    </tr>
                    <?php
                        }
                    }
                    ?>
                  </table>
                  
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                    <?php echo $this->pagination->create_links(); ?>
                </div>
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('ul.pagination li a').click(function (e) {
            e.preventDefault();            
            var link = jQuery(this).get(0).href;            
            var value = link.substring(link.lastIndexOf('/') + 1);
            jQuery("#searchList").attr("action", baseURL + "userListing/" + value);
            jQuery("#searchList").submit();
        });
    });
</script>
