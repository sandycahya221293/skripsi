<?php

$noso = '';
$kodegambar  = '';
$tglpenerimaan ='';
$konstruksi = '';
$instruksi  = '';
$tracer  = '';
$tgltracer ='';
$tglkelar = '';
$tglkirim = '';
$tglorderproduk  = '';
$keterangan  = '';
$idcostumer = '';
$id = '';


if(!empty($datastrikeInfo))
{
    foreach ($datastrikeInfo as $uf)
    {
        $noso = $uf->noso;
        $kodegambar = $uf->kodegambar;
        $tglpenerimaan= $uf->tglpenerimaan;
        $konstruksi = $uf->konstruksi;
        $instruksi = $uf->instruksi;
        $tracer = $uf->tracer;
        $tgltracer= $uf->tgltracer;
        $tglkelar = $uf->tglkelar;
        $tglkirim = $uf->tglkirim;
        $tglorderproduk  = $uf->tglorderproduk;
        $keterangan  = $uf->keterangan;
      
    }
}


?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-users"></i> Data Strike Off Management
        <small>Add / Edit Data</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Data Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" action="<?php echo base_url() ?>editStrike" method="post" id="editUser" role="form">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="nodesain">No Strikeoff</label>
                                        <input type="text" class="form-control" id="noso" placeholder="No Strikeoff" name="noso" value="<?php echo $noso; ?>" maxlength="128">
                                    </div>
                                    
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="kodegambar">Kode Gambar</label>
                                        <input type="text" class="form-control" id="kodegambar" placeholder="Kode Gambar" name="kodegambar" value="<?php echo $kodegambar; ?>" maxlength="128">
                                    </div>
                                </div>
                           
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="costumer">Costumer</label>
                                        <select class="form-control" id="costumer" name="costumer">
                                        <option value="0">Select Costumer</option>
                                            <?php
                                            if(!empty($costumer))
                                            {
                                                foreach ($costumer as $rl)
                                                {
                                                    ?>
                                                    <option value="<?php echo $rl->idcostumer; ?>" <?php if($rl->idcostumer == $idcostumer) {echo "selected=selected";} ?>><?php echo $rl->nama ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="telepon">Tanggal Penerimaan</label>
                                        <input type="date" class="form-control" id="tglpenerimaan" placeholder="Tanggal Penerimaan" name="tglpenerimaan" value="<?php echo $tglpenerimaan; ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="konstruksi">Konstruksi</label>
                                        <select class="form-control" id="konstruksi" name="konstruksi">
                                        <option value="0">Select Konstruksi</option>
                                            <?php
                                            if(!empty($kl))
                                            {
                                                foreach ($kl as $rl)
                                                {
                                                    ?>
                                                    <option value="<?php echo $rl->id; ?>" <?php if($rl->id == $id) {echo "selected=selected";} ?>><?php echo $rl->nama ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="instruksi">Instruksi</label>
                                        <input type="text" class="form-control" id="instruksi" placeholder="Instruksi" name="instruksi" value="<?php echo $instruksi; ?>" maxlength="128">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="tracer">Tracer</label>
                                        <select class="form-control" id="tracer" name="tracer">
                                        <option value="0">Select Tracer</option>
                                            <?php
                                            if(!empty($tr))
                                            {
                                                foreach ($tr as $rl)
                                                {
                                                    ?>
                                                    <option value="<?php echo $rl->id; ?>" <?php if($rl->id == $id) {echo "selected=selected";} ?>><?php echo $rl->nama ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                 <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="tgltracer">Tanggal Tracer</label>     
                                        <input type="date" class="form-control" id="tgltracer" placeholder="Tanggal Tracer" name="tgltracer" value="<?php echo $tgltracer; ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="tglkelar">Tanggal kelar</label>
                                        <input type="date" class="form-control" id="tglkelar" placeholder="Tanggal Kelar" name="tglkelar" value="<?php echo $tglkelar; ?>">
                                    </div>
                                </div>
                           
                                 <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="tglkirim">Tanggal Kirim</label>     
                                        <input type="date" class="form-control" id="tglkirim" placeholder="Tanggal Kirim" name="tglkirim " value="<?php echo $tglkirim; ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="tglorderproduk">Tanggal Order Produk</label>
                                        <input type="date" class="form-control" id="tglorderproduk" placeholder="Tanggal Order Produk" name="tglorderproduk" value="<?php echo $tglorderproduk; ?>">
                                    </div>
                                </div>
                              <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="keterangan">Keterangan</label>
                                        <input type="text" class="form-control" id="keterangan" placeholder="Keterangan" name="keterangan" value="<?php echo $keterangan; ?>">
                                    </div>
                                </div>
                        </div>
                        <div class="box-footer" >
                            <input type="submit" class="btn btn-primary" value="Edit" />
                            <input type="reset" class="btn btn-default" value="Kembali" />
                        </div>
                    
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
</div>

<script src="<?php echo base_url(); ?>assets/js/editUser.js" type="text/javascript"></script>