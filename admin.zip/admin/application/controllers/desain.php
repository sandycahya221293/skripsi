<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : User (UserController)
 * User Class to control all user related operations.
 * @author : Kishor Mali
 * @version : 1.1
 * @since : 15 November 2016
 */
class Desain extends BaseController
{
	 // listing desain 
    function desainListing()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('user_model');
        
            $searchText = $this->input->post('searchText');
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->user_model->userListingCount($searchText);

            $returns = $this->paginationCompress ( "desainListing/", $count, 5 );
            
            $data['dataRecords'] = $this->user_model->desainListing($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'CodeInsect : desain Listing';
            
            $this->loadViews("datadesain", $this->global, $data, NULL);
        }
    }

     function addDataDesain()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('user_model');
            $data['tr'] = $this->user_model->getTracer();
            $data['kl'] = $this->user_model->getKonstruksi();
            $data['costumer'] = $this->user_model->getCostumer();
            
            $this->global['pageTitle'] = 'CodeInsect : Add New User';

            $this->loadViews("addDatadesain", $this->global, $data, NULL);
        }
    }

    function addNewDatadesain()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('nodesain','No Desain','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('kodegambar','Kode Gambar','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('costumer','Costumer','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('tglpenerimaan','Tanggal Peneriman','trim|max_length[128]|xss_clean');
            $this->form_validation->set_rules('noso','No SO','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('konstruksi','Konstruksi','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('instruksi','Instruksi','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('tracer','Tracer','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('tgltracer','Tanggal Tracer','trim|max_length[128]|xss_clean');
            $this->form_validation->set_rules('tglkelar','Tanggal Kelar','trim|max_length[128]|xss_clean');
            $this->form_validation->set_rules('tglkirim','Tanggal Kirim','trim|max_length[128]|xss_clean');
            $this->form_validation->set_rules('tglorderproduk','Tanggal Order Produk','trim|max_length[128]|xss_clean');
            $this->form_validation->set_rules('keterangan','keterangan','trim|required|max_length[128]|xss_clean');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->addDatadesain();
            }
            else
            {
                $nodesain = ucwords(strtolower($this->input->post('nodesain')));
                $kodegambar = $this->input->post('kodegambar');
                $costumer = $this->input->post('costumer');
                $tglpenerimaan = $this->input->post('tglpenerimaan');
                $noso = $this->input->post('noso');
                $konstruksi = $this->input->post('konstruksi');
                $instruksi = $this->input->post('instruksi');
                $tracer = $this->input->post('tracer');
                $tgltracer = $this->input->post('tgltracer');
                $tglkelar = $this->input->post('tglkelar');
                $tglkirim = $this->input->post('tglkirim');
                $tglorderproduk = $this->input->post('tglorderproduk');
                $keterangan = $this->input->post('keterangan');
                
                $dataInfo = array('nodesain'=>$nodesain,'kodegambar'=>$kodegambar, 'costumer'=> $costumer,
                                  'tglpenerimaan'=>$tglpenerimaan, 'noso'=>$noso, 'konstruksi'=>$konstruksi,
                                  'instruksi'=>$instruksi, 'tracer'=>$tracer, 'tgltracer'=>$tgltracer, 'tglkelar'=>$tglkelar,
                                  ' '=>$tglkirim, 'tglorderproduk'=>$tglorderproduk, 'keterangan'=>$keterangan);
                
                $this->load->model('user_model');
                $result = $this->user_model->addNewDatadesain($dataInfo);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'New Data Desain created successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Data Desain creation failed');
                }
                
                redirect('addDatadesain');
            }
        }
    }
     
    //fungsi edit data desain
    function editdatadesain($nodesain = NULL)
    {
        if($this->isAdmin() == TRUE )
        {
            $this->loadThis();
        }
        else
        {
            if($nodesain == null)
            {
                redirect('desainListing');
            }
            $data['tr'] = $this->user_model->getTracer();
            $data['kl'] = $this->user_model->getKonstruksi();
            $data['costumer'] = $this->user_model->getCostumer();
            $data['datadesainInfo'] = $this->user_model->getdatadesainInfo($nodesain);
            
            $this->global['pageTitle'] = 'Indopasific : Edit Data Desain';
            
            $this->loadViews("editdesain", $this->global, $data, NULL);
        }
    }
}
?>