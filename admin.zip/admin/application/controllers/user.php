<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : User (UserController)
 * User Class to control all user related operations.
 * @author : Kishor Mali
 * @version : 1.1
 * @since : 15 November 2016
 */
class User extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('user_model');
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the user
     */
    public function index()
    {
        $this->global['pageTitle'] = 'Indopasific : Dashboard';
        
        $this->loadViews("dashboard", $this->global, NULL , NULL);
    }
    
    /**
     * This function is used to load the user list
     */
    function userListing()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('user_model');
        
            $searchText = $this->input->post('searchText');
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->user_model->userListingCount($searchText);

			$returns = $this->paginationCompress ( "userListing/", $count, 10 );
            
            $data['userRecords'] = $this->user_model->userListing($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'CodeInsect : User Listing';
            
            $this->loadViews("users", $this->global, $data, NULL);
        }
    }

    // listing data 
    function dataListing()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('user_model');
        
            $searchText = $this->input->post('searchText');
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->user_model->nosoListingCount($searchText);

            $returns = $this->paginationCompress ( "dataListing/", $count, 5 );
            
            $data['dataRecords'] = $this->user_model->dataListing($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'CodeInsect : data Listing';
            
            $this->loadViews("datastrike", $this->global, $data, NULL);
        }
    }


 function desainListing()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('user_model');
        
            $searchText = $this->input->post('searchText');
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->user_model->desainListingCount($searchText);

            $returns = $this->paginationCompress ( "desainListing/", $count, 5 );
            
            $data['dataRecords'] = $this->user_model->desainListing($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'CodeInsect : desain Listing';
            
            $this->loadViews("datadesain", $this->global, $data, NULL);
        }
    }

  function produksiListing()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('user_model');
        
            $searchText = $this->input->post('searchText');
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->user_model->userListingCount($searchText);

            $returns = $this->paginationCompress ( "produksiListing/", $count, 5 );
            
            $data['dataRecords'] = $this->user_model->produksiListing($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'CodeInsect : produksi Listing';
            
            $this->loadViews("dataproduksi", $this->global, $data, NULL);
        }
    }
    

    
    /**
     * This function is used to load the add new form
     */
    function addNew()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('user_model');
            $data['roles'] = $this->user_model->getUserRoles();
            
            $this->global['pageTitle'] = 'CodeInsect : Add New User';

            $this->loadViews("addNew", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to check whether email already exist or not
     */
    function checkEmailExists()
    {
        $userId = $this->input->post("userId");
        $email = $this->input->post("email");

        if(empty($userId)){
            $result = $this->user_model->checkEmailExists($email);
        } else {
            $result = $this->user_model->checkEmailExists($email, $userId);
        }

        if(empty($result)){ echo("true"); }
        else { echo("false"); }
    }
    
    /**
     * This function is used to add new user to the system
     */
    function addNewUser()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('nama','Full Name','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('email','Email','trim|required|valid_email|xss_clean|max_length[128]');
            $this->form_validation->set_rules('alamat','Alamat','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('telepon','Telepon','trim|required|numeric');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->addNew();
            }
            else
            {
                $nama = ucwords(strtolower($this->input->post('nama')));
                $email = $this->input->post('email');
                $alamat = $this->input->post('alamat');
                $telepon = $this->input->post('telepon');
                
                $userInfo = array('nama'=>$nama,'email'=>$email, 'alamat'=> $alamat,
                                    'telepon'=>$telepon);
                
                $this->load->model('user_model');
                $result = $this->user_model->addNewUser($userInfo);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'Data berhasil ditambahkan');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Data yang ditambahkan tidak lengkap');
                }
                
                redirect('addNew');
            }
        }
    }

    /**
     * This function is used load user edit information
     * @param number $userId : Optional : This is user id
     */
    function editOld($idcostumer = NULL)
    {
        if($this->isAdmin() == TRUE || $idcostumer == 1)
        {
            $this->loadThis();
        }
        else
        {
            if($idcostumer == null)
            {
                redirect('userListing');
            }
            
           ///$data['roles'] = $this->user_model->getUserRoles();
            $data['userInfo'] = $this->user_model->getUserInfo($idcostumer);
            
            $this->global['pageTitle'] = 'Indopasific : Edit User';
            
            $this->loadViews("editOld", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to edit the user information
     */

    //edit user dari form edit
    function editUser()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $idcostumer = $this->input->post('idcostumer');
            
            $this->form_validation->set_rules('nama','Full Name','trim|max_length[128]|xss_clean');
            $this->form_validation->set_rules('email','Email','trim|required|valid_email|xss_clean|max_length[128]');
            $this->form_validation->set_rules('alamat','Alamat','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('telepon','Telepon','trim|numeric');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->editOld($idcostumer);
            }
            else
            {
                $nama = ucwords(strtolower($this->input->post('nama')));
                $email = $this->input->post('email');
                $alamat = $this->input->post('alamat');
                $telepon = $this->input->post('telepon');
                
                $userInfo = array('nama'=>$nama,'email'=>$email, 'alamat'=> $alamat,
                                    'telepon'=>$telepon);
                
                if(empty($nama))
                {
                    $userInfo = array('nama'=>ucwords($nama),'email'=>$email, 'alamat'=>$alamat, 'telepon'=>$telepon);
                }
                else
                {
                   // $userInfo = array('nama'=>ucwords($nama),'email'=>$email, 'alamat'=>$alamat, 'telepon'=>$telepon);
                }
                
                $result = $this->user_model->editUser($userInfo, $idcostumer);
                
                if($result == true)
                {
                    $this->session->set_flashdata('success', 'Data berhasil dirubah');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Data perubahan salah');
                }
                
                redirect('userListing');
            }
        }
    }
//fungsi edit data strike
    function editStrike()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $noso = $this->input->post('noso');
            
            $this->form_validation->set_rules('noso','No Strike Off','trim|required|max_length[128]|is_unique[tbl_strikeoff.noso]|xss_clean');
            $this->form_validation->set_rules('kodegambar','Kode Gambar','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('costumer','Costumer','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('tglpenerimaan','Tanggal Peneriman','trim|max_length[128]|xss_clean');
            $this->form_validation->set_rules('konstruksi','Konstruksi','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('instruksi','Instruksi','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('tracer','Tracer','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('tgltracer','Tanggal Tracer','trim|max_length[128]|xss_clean');
            $this->form_validation->set_rules('tglkelar','Tanggal Kelar','trim|max_length[128]|xss_clean');
            $this->form_validation->set_rules('tglkirim','Tanggal Kirim','trim|max_length[128]|xss_clean');
            $this->form_validation->set_rules('tglorderproduk','Tanggal Order Produk','trim|max_length[128]|xss_clean');
            $this->form_validation->set_rules('keterangan','keterangan','trim|required|max_length[128]|xss_clean');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->editStrike($noso);
            }
            else
            {
                $noso = $this->input->post('noso');
                $kodegambar = $this->input->post('kodegambar');
                $costumer = $this->input->post('costumer');
                $tglpenerimaan = $this->input->post('tglpenerimaan');
                $konstruksi = $this->input->post('konstruksi');
                $instruksi = $this->input->post('instruksi');
                $tracer = $this->input->post('tracer');
                $tgltracer = $this->input->post('tgltracer');
                $tglkelar = $this->input->post('tglkelar');
                $tglkirim = $this->input->post('tglkirim');
                $tglorderproduk = $this->input->post('tglorderproduk');
                $keterangan = $this->input->post('keterangan');

                $dataInfo = array('noso'=>$noso,
                                  'kodegambar'=>$kodegambar, 
                                  'costumer'=> $costumer,
                                  'tglpenerimaan'=>$tglpenerimaan,
                                  'konstruksi'=>$konstruksi, 
                                  'instruksi'=> $instruksi,
                                  'tracer'=>$tracer,
                                  'tgltracer'=>$tgltracer,
                                  'tglkelar'=>$tglkelar, 
                                  'tglkirim'=> $tglkirim,
                                  'tglorderproduk'=>$tglorderproduk,
                                  'keterangan'=>$keterangan);
                
                
                $result = $this->user_model->editStrike($dataInfo, $noso);
                
                if($result == true)
                {
                    $this->session->set_flashdata('success', 'Data berhasil dirubah');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Data perubahan salah');
                }
                
                redirect('dataListing');
            }
        }
    }


    public function delete($idcostumer)
    {
        $id = $this->uri->segment(3);
        
        if (empty($idcostumer))
        {
            show_404();
        }
                
        
        if($this->user_model->delete_user($idcostumer)){
            
            $this->session->set_flashdata('message', 'Data berhasil dihapus');
           
            redirect('userListing');  
        } 
    }

    public function deleteStrike($nodesain)
    {
        $id = $this->uri->segment(3);
        
        if (empty($nodesain))
        {
            show_404();
        }
                
        
        if($this->user_model->delete_strike($nodesain)){
            
            $this->session->set_flashdata('message', 'Data berhasil dihapus');
           
            redirect('dataListing');  
        } 
    }

    public function deleteDesain($nodesain)
    {
        $id = $this->uri->segment(3);
        
        if (empty($nodesain))
        {
            show_404();
        }
                
        
        if($this->user_model->delete_desain($nodesain)){
            
            $this->session->set_flashdata('message', 'Data berhasil dihapus');
           
            redirect('desainListing');  
        } 
    }

    public function deleteProduksi($no)
    {
        $id = $this->uri->segment(3);
        
        if (empty($no))
        {
            show_404();
        }
                
        
        if($this->user_model->delete_produksi($no)){
            
            $this->session->set_flashdata('message', 'Data berhasil dihapus');
           
            redirect('produksiListing');  
        } 
    }

     function addDatastrike()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('user_model');
            $data['tr'] = $this->user_model->getTracer();
            $data['kl'] = $this->user_model->getKonstruksi();
            $data['costumer'] = $this->user_model->getCostumer();
            
            $this->global['pageTitle'] = 'CodeInsect : Add New User';

            $this->loadViews("addDatastrike", $this->global, $data, NULL);
        }
    }

    function addDataDesain()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('user_model');
            $data['tr'] = $this->user_model->getTracer();
            $data['kl'] = $this->user_model->getKonstruksi();
            $data['costumer'] = $this->user_model->getCostumer();
            
            $this->global['pageTitle'] = 'CodeInsect : Add New User';

            $this->loadViews("addDataDesain", $this->global, $data, NULL);
        }
    }

    function addDataProduksi()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('user_model');
            $data['tr'] = $this->user_model->getTracer();
            $data['kl'] = $this->user_model->getKonstruksi();
            $data['costumer'] = $this->user_model->getCostumer();
            $data['noso'] = $this->user_model->getNoso();
            $data['nodesain'] =$this->user_model->getNodesain();
            $this->global['pageTitle'] = 'CodeInsect : Add New User';

            $this->loadViews("addDataProduksi", $this->global, $data, NULL);
        }
    }

    function addNewDatastrike()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('noso','No Strike Off','trim|required|max_length[128]|is_unique[tbl_strikeoff.noso]|xss_clean');
            $this->form_validation->set_rules('kodegambar','Kode Gambar','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('costumer','Costumer','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('tglpenerimaan','Tanggal Peneriman','trim|max_length[128]|xss_clean');
            $this->form_validation->set_rules('konstruksi','Konstruksi','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('instruksi','Instruksi','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('tracer','Tracer','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('tgltracer','Tanggal Tracer','trim|max_length[128]|xss_clean');
            $this->form_validation->set_rules('tglkelar','Tanggal Kelar','trim|max_length[128]|xss_clean');
            $this->form_validation->set_rules('tglkirim','Tanggal Kirim','trim|max_length[128]|xss_clean');
            $this->form_validation->set_rules('tglorderproduk','Tanggal Order Produk','trim|max_length[128]|xss_clean');
            $this->form_validation->set_rules('keterangan','keterangan','trim|required|max_length[128]|xss_clean');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->addDatastrike(); 
            }
            else
            {
                $noso = ucwords(strtolower($this->input->post('noso')));
                $kodegambar = $this->input->post('kodegambar');
                $costumer = $this->input->post('costumer');
                $tglpenerimaan = $this->input->post('tglpenerimaan');
                $konstruksi = $this->input->post('konstruksi');
                $instruksi = $this->input->post('instruksi');
                $tracer = $this->input->post('tracer');
                $tgltracer = $this->input->post('tgltracer');
                $tglkelar = $this->input->post('tglkelar');
                $tglkirim = $this->input->post('tglkirim');
                $tglorderproduk = $this->input->post('tglorderproduk');
                $keterangan = $this->input->post('keterangan');
                
                $dataInfo = array('noso'=>$noso,'kodegambar'=>$kodegambar, 'costumer'=> $costumer,
                                  'tglpenerimaan'=>$tglpenerimaan, 'konstruksi'=>$konstruksi,
                                  'instruksi'=>$instruksi, 'tracer'=>$tracer, 'tgltracer'=>$tgltracer, 'tglkelar'=>$tglkelar,
                                  'tglkirim'=>$tglkirim, 'tglorderproduk'=>$tglorderproduk, 'keterangan'=>$keterangan);
                
                $this->load->model('user_model');
                $result = $this->user_model->addNewDatastrike($dataInfo);
                
                if($result != 0)
                {
                    $this->session->set_flashdata('success', 'Data berhasil ditambahkan');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Data tidak berhasil disimpan');
                }
                
                redirect('dataListing');
            }
        }
    }


    function addNewDataDesain()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('nodesain','No Desain','trim|required|max_length[128]|is_unique[tbl_desain.nodesain]|xss_clean');
            $this->form_validation->set_rules('kodegambar','Kode Gambar','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('costumer','Costumer','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('tglpenerimaan','Tanggal Peneriman','trim|max_length[128]|xss_clean');
            $this->form_validation->set_rules('konstruksi','Konstruksi','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('instruksi','Instruksi','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('tracer','Tracer','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('tgltracer','Tanggal Tracer','trim|max_length[128]|xss_clean');
            $this->form_validation->set_rules('tglkelar','Tanggal Kelar','trim|max_length[128]|xss_clean');
            $this->form_validation->set_rules('tglkirim','Tanggal Kirim','trim|max_length[128]|xss_clean');
            $this->form_validation->set_rules('tglorderproduk','Tanggal Order Produk','trim|max_length[128]|xss_clean');
            $this->form_validation->set_rules('keterangan','keterangan','trim|required|max_length[128]|xss_clean');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->addDataDesain();
            }
            else
            {
                $nodesain = ucwords(strtolower($this->input->post('nodesain')));
                $kodegambar = $this->input->post('kodegambar');
                $costumer = $this->input->post('costumer');
                $tglpenerimaan = $this->input->post('tglpenerimaan');
                $konstruksi = $this->input->post('konstruksi');
                $instruksi = $this->input->post('instruksi');
                $tracer = $this->input->post('tracer');
                $tgltracer = $this->input->post('tgltracer');
                $tglkelar = $this->input->post('tglkelar');
                $tglkirim = $this->input->post('tglkirim');
                $tglorderproduk = $this->input->post('tglorderproduk');
                $keterangan = $this->input->post('keterangan');
                
                $dataInfo = array('nodesain'=>$nodesain,'kodegambar'=>$kodegambar, 'costumer'=> $costumer,
                                  'tglpenerimaan'=>$tglpenerimaan, 'konstruksi'=>$konstruksi,
                                  'instruksi'=>$instruksi, 'tracer'=>$tracer, 'tgltracer'=>$tgltracer, 'tglkelar'=>$tglkelar,
                                  'tglkirim'=>$tglkirim, 'tglorderproduk'=>$tglorderproduk, 'keterangan'=>$keterangan);
                
                $this->load->model('user_model');
                $result = $this->user_model->addNewDataDesain($dataInfo);
                
                if($result != 0)
                {
                    $this->session->set_flashdata('success', 'Data berhasil ditambahkan');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Data tidak berhasil disimpan');
                }
                
                redirect('desainListing');
            }
        }
    }

    function addNewDataProduksi()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('noproduksi','No Produksi','trim|required|max_length[128]|is_unique[tbl_produksi.no]|xss_clean');
            $this->form_validation->set_rules('kodegambar','Kode Gambar','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('costumer','Costumer','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('tglpenerimaan','Tanggal Peneriman','trim|max_length[128]|xss_clean');
            $this->form_validation->set_rules('konstruksi','Konstruksi','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('combo','Combo','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('noso','No Strikeoff','trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('nodesain','No Desain','trim|max_length[128]|xss_clean');
            $this->form_validation->set_rules('tglselesai','Tanggal Selesai','trim|max_length[128]|xss_clean');
            $this->form_validation->set_rules('desainer','Desainer','trim|max_length[128]|xss_clean');
            $this->form_validation->set_rules('keterangan','keterangan','trim|required|max_length[128]|xss_clean');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->addDataProduksi();
            }
            else
            {
                $noproduksi = ucwords(strtolower($this->input->post('noproduksi')));
                $kodegambar = $this->input->post('kodegambar');
                $costumer = $this->input->post('costumer');
                $tglpenerimaan = $this->input->post('tglpenerimaan');
                $konstruksi = $this->input->post('konstruksi');
                $combo = $this->input->post('combo');
                $noso = $this->input->post('noso');
                $nodesain = $this->input->post('nodesain');
                $tglselesai = $this->input->post('tglselesai');
                $desainer = $this->input->post('desainer');
                $keterangan = $this->input->post('keterangan');
                
                $dataInfo = array('no'=>$noproduksi,'tglterima'=>$tglpenerimaan, 'costumer'=> $costumer,
                                  'konstruksi'=>$konstruksi,'kodegambar'=>$kodegambar, 'nodesain'=>$nodesain, 'noso'=>$noso, 'tglselesai'=>$tglselesai,
                                  'combo'=>$combo, 'desainer'=>$desainer, 'keterangan'=>$keterangan);
                
                $this->load->model('user_model');
                $result = $this->user_model->addNewDataProduksi($dataInfo);
                
                if($result != 0)
                {
                    $this->session->set_flashdata('success', 'Data berhasil ditambahkan');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Data tidak berhasil disimpan');
                }
                
                redirect('produksiListing');
            }
        }
    }
     
    //fungsi edit data strikeoff
    function editdatastrike($noso = NULL)
    {
        if($this->isAdmin() == TRUE )
        {
            $this->loadThis();
        }
        else
        {
            if($noso == null)
            {
                redirect('dataListing');
            }
            $data['tr'] = $this->user_model->getTracer();
            $data['kl'] = $this->user_model->getKonstruksi();
            $data['costumer'] = $this->user_model->getCostumer();
            $data['datastrikeInfo'] = $this->user_model->getdatastrikeInfo($noso);
            
            $this->global['pageTitle'] = 'Indopasific : Edit Data Strike Off';
            
            $this->loadViews("editStrike", $this->global, $data, NULL);
        }
    }


    function editdatadesain($nodesain = NULL)
    {
        if($this->isAdmin() == TRUE )
        {
            $this->loadThis();
        }
        else
        {
            if($nodesain == null)
            {
                redirect('dataListing');
            }
            $data['tr'] = $this->user_model->getTracer();
            $data['kl'] = $this->user_model->getKonstruksi();
            $data['costumer'] = $this->user_model->getCostumer();
            $data['datastrikeInfo'] = $this->user_model->getdatastrikeInfo($nodesain);
            
            $this->global['pageTitle'] = 'Indopasific : Edit Data Desain Off';
            
            $this->loadViews("editDesain", $this->global, $data, NULL);
        }
    }

   


    function loadChangePass()
    {
        $this->global['pageTitle'] = 'CodeInsect : Change Password';
        
        $this->loadViews("changePassword", $this->global, NULL, NULL);
    }
    
    
    /**
     * This function is used to change the password of the user
     */
    function changePassword()
    {
        $this->load->library('form_validation');
        
        $this->form_validation->set_rules('oldPassword','Old password','required|max_length[20]');
        $this->form_validation->set_rules('newPassword','New password','required|max_length[20]');
        $this->form_validation->set_rules('cNewPassword','Confirm new password','required|matches[newPassword]|max_length[20]');
        
        if($this->form_validation->run() == FALSE)
        {
            $this->loadChangePass();
        }
        else
        {
            $oldPassword = $this->input->post('oldPassword');
            $newPassword = $this->input->post('newPassword');
            
            $resultPas = $this->user_model->matchOldPassword($this->vendorId, $oldPassword);
            
            if(empty($resultPas))
            {
                $this->session->set_flashdata('nomatch', 'Password salah');
                redirect('loadChangePass');
            }
            else
            {
                $usersData = array('password'=>getHashedPassword($newPassword), 'updatedBy'=>$this->vendorId,
                                'updatedDtm'=>date('Y-m-d H:i:s'));
                
                $result = $this->user_model->changePassword($this->vendorId, $usersData);
                
                if($result > 0) { $this->session->set_flashdata('success', 'Password berhasil dirubah'); }
                else { $this->session->set_flashdata('error', 'Password gagal dirubah'); }
                
                redirect('loadChangePass');
            }
        }
    }

    function pageNotFound()
    {
        $this->global['pageTitle'] = 'CodeInsect : 404 - Page Not Found';
        
        $this->loadViews("404", $this->global, NULL, NULL);
    }
}

?>