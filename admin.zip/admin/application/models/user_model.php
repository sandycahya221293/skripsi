<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class User_model extends CI_Model
{
    /**
     * This function is used to get the user listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function userListingCount($searchText = '')
    {
        $this->db->select('BaseTbl.userId, BaseTbl.email, BaseTbl.name, BaseTbl.mobile, Role.role');
        $this->db->from('tbl_users as BaseTbl');
        $this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.email  LIKE '%".$searchText."%'
                            OR  BaseTbl.name  LIKE '%".$searchText."%'
                            OR  BaseTbl.mobile  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.roleId !=', 1);
        $query = $this->db->get();
        
        return count($query->result());
    }

    function nosoListingCount($searchText = '')
   {
        $this->db->select('noso, kodegambar, costumer, tglpenerimaan, konstruksi, instruksi, tracer, tgltracer, tglkelar, tglkirim, tglorderproduk, keterangan');
        $this->db->from('tbl_strikeoff');
        if(!empty($searchText)) {
            $likeCriteria = "(noso  LIKE '%".$searchText."%'
                            OR  kodegambar  LIKE '%".$searchText."%'
                            OR  costumer  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
       
        $query = $this->db->get();
        return count($query->result());
    }

    
    function desainListingCount($searchText = '')
   {
        $this->db->select('nodesain, kodegambar, costumer, tglpenerimaan, konstruksi, instruksi, tracer, tgltracer, tglkelar, tglkirim, tglorderproduk, keterangan ');
        $this->db->from('tbl_desain');
        if(!empty($searchText)) {
            $likeCriteria = "(nodesain  LIKE '%".$searchText."%'
                            OR  kodegambar  LIKE '%".$searchText."%'
                            OR  costumer  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
       
        $query = $this->db->get();
        return count($query->result());
    }
    

     
    function produksiListingCount($searchText = '')
   {
        $this->db->select('no, tglterima, costumer, kodegambar, nodesain, noso, konstruksi, combo, tglselesai, desainer, keterangan');
        $this->db->from('tbl_produksi');
        if(!empty($searchText)) {
            $likeCriteria = "(no  LIKE '%".$searchText."%'
                            OR  kodegambar  LIKE '%".$searchText."%'
                            OR  costumer  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
       
        $query = $this->db->get();
        return count($query->result());
    }
    
    /**
     * This function is used to get the user listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function userListing($searchText = '', $page, $segment)
    {
        $this->db->select('idcostumer, nama, email, alamat, telepon');
        $this->db->from('tbl_costumer');
        if(!empty($searchText)) {
            $likeCriteria = "(nama  LIKE '%".$searchText."%'
                            OR  email  LIKE '%".$searchText."%'
                            OR  telepon  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
      
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }

     function dataListing($searchText = '', $page, $segment)
    {
        $this->db->select('noso, kodegambar, costumer, tglpenerimaan, konstruksi, instruksi, tracer, tgltracer, tglkelar, tglkirim, tglorderproduk, keterangan ');
        $this->db->from('tbl_strikeoff');
        if(!empty($searchText)) {
            $likeCriteria = "(noso  LIKE '%".$searchText."%'
                            OR  kodegambar  LIKE '%".$searchText."%'
                            OR  costumer  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }

    function desainListing($searchText = '', $page, $segment)
    {
        $this->db->select('nodesain, kodegambar, costumer, tglpenerimaan, konstruksi, instruksi, tracer, tgltracer, tglkelar, tglkirim, tglorderproduk, keterangan ');
        $this->db->from('tbl_desain');
        if(!empty($searchText)) {
            $likeCriteria = "(nodesain  LIKE '%".$searchText."%'
                            OR  kodegambar  LIKE '%".$searchText."%'
                            OR  costumer  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }
    

    function produksiListing($searchText = '', $page, $segment)
    {
        $this->db->select('no, tglterima, costumer, kodegambar, nodesain, noso, konstruksi, combo, tglselesai, desainer, keterangan');
        $this->db->from('tbl_produksi');
        //$this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');
        if(!empty($searchText)) {
            $likeCriteria = "(no  LIKE '%".$searchText."%'
                            OR  kodegambar  LIKE '%".$searchText."%'
                            OR  costumer  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }
    /**
     * This function is used to get the user roles information
     * @return array $result : This is result of the query
     */
    function getUserRoles()
    {
        $this->db->select('roleId, role');
        $this->db->from('tbl_roles');
        $this->db->where('roleId !=', 1);
        $query = $this->db->get();
        
        return $query->result();
    }
    

     function getCostumer()
    {
        $this->db->select('idcostumer, nama');
        $this->db->from('tbl_costumer');
        $query = $this->db->get();
        
        return $query->result();
    }
    
    function getKonstruksi()
    {
        $this->db->select('id, nama');
        $this->db->from('tbl_kontruksi');
        $query = $this->db->get();
        
        return $query->result();
    }
   

    function getTracer()
    {
        $this->db->select('id, nama');
        $this->db->from('tbl_tracer');
        $query = $this->db->get();
        
        return $query->result();
    }

    
    function getNodesain()
    {
        $this->db->select('nodesain');
        $this->db->from('tbl_desain');
        $query = $this->db->get();
        
        return $query->result();
    }
    

    
    function getNoso()
    {
        $this->db->select('noso');
        $this->db->from('tbl_strikeoff');
        $query = $this->db->get();
        
        return $query->result();
    }
    

    /**
     * This function is used to check whether email id is already exist or not
     * @param {string} $email : This is email id
     * @param {number} $userId : This is user id
     * @return {mixed} $result : This is searched result
     */
    function checkEmailExists($email, $userId = 0)
    {
        $this->db->select("email");
        $this->db->from("tbl_users");
        $this->db->where("email", $email);   
        $this->db->where("isDeleted", 0);
        if($userId != 0){
            $this->db->where("userId !=", $userId);
        }
        $query = $this->db->get();

        return $query->result();
    }
    
    
    /**
     * This function is used to add new user to system
     * @return number $insert_id : This is last inserted id
     */
    function addNewUser($userInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_costumer', $userInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }

    function addNewDatastrike($datainfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_strikeoff', $datainfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();

        return $insert_id;
    }


    function addNewDataDesain($datainfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_desain', $datainfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    

    function addNewDataProduksi($datainfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_produksi', $datainfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    /**
     * This function used to get user information by id
     * @param number $userId : This is user id
     * @return array $result : This is user information
     */
    function getUserInfo($idcostumer)
    {
        $this->db->select('idcostumer, nama, email, alamat, telepon');
        $this->db->from('tbl_costumer');
        $this->db->where('idcostumer', $idcostumer);
        $query = $this->db->get();
        
        return $query->result();
    }
    

    function getdatastrikeInfo($noso)
    
    {
        $this->db->select('*');
        $this->db->from('tbl_strikeoff');
        $this->db->where('noso', $noso);
        $query = $this->db->get();
        
        return $query->result();
    }
    
    
    /**
     * This function is used to update the user information
     * @param array $userInfo : This is users updated information
     * @param number $userId : This is user id
     */
    function editUser($userInfo, $idcostumer)
    {
        $this->db->where('idcostumer', $idcostumer);
        $this->db->update('tbl_costumer', $userInfo);

        return TRUE;
    }

    function editStrike($dataInfo, $noso)
    {
        $this->db->where('noso', $noso);
        $this->db->update('tbl_strikeoff', $dataInfo);

        return TRUE;
    }
    
    
    /**
     * This function is used to delete the user information
     * @param number $userId : This is idcostumer
     * @return boolean $result : TRUE / FALSE
     */
    public function delete_user($idcostumer){
        $this->db->where("idcostumer", $idcostumer);
        $this->db->delete('tbl_costumer');
        return $this->db->affected_rows();
    }
    

    public function delete_strike($noso){
        $this->db->where("noso", $noso);
        $this->db->delete('tbl_strikeoff');
        return $this->db->affected_rows();
    }

    public function delete_desain($nodesain){
        $this->db->where("nodesain", $nodesain);
        $this->db->delete('tbl_desain');
        return $this->db->affected_rows();
    }
    
    public function delete_produksi($no){
        $this->db->where("no", $no);
        $this->db->delete('tbl_produksi');
        return $this->db->affected_rows();
    }
    
    /**
     * This function is used to match users password for change password
     * @param number $userId : This is user id
     */
    function matchOldPassword($userId, $oldPassword)
    {
        $this->db->select('userId, password');
        $this->db->where('userId', $userId);        
        $this->db->where('isDeleted', 0);
        $query = $this->db->get('tbl_users');
        
        $user = $query->result();

        if(!empty($user)){
            if(verifyHashedPassword($oldPassword, $user[0]->password)){
                return $user;
            } else {
                return array();
            }
        } else {
            return array();
        }
    }
    
    /**
     * This function is used to change users password
     * @param number $userId : This is user id
     * @param array $userInfo : This is user updation info
     */
    function changePassword($userId, $userInfo)
    {
        $this->db->where('userId', $userId);
        $this->db->where('isDeleted', 0);
        $this->db->update('tbl_users', $userInfo);
        
        return $this->db->affected_rows();
    }
}

  